/* -----------------------------------------------------------------------
   AIS Parser SDK
   Copyright 2006-2008 by Brian C. Lane <bcl@brianlane.com>
   All rights Reserved
   ----------------------------------------------------------------------- */
void test_access( void );
