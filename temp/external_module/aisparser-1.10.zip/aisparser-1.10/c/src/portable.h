#ifndef _WIN32
#ifndef __cygwin__
#  define __cdecl    /* nothing */
#  define __stdcall  /* nothing */
#  define __fastcall /* nothing */
#endif /* __cygwin__ */
#endif /* _WIN32 */
