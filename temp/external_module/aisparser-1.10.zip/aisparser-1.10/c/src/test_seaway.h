/* -----------------------------------------------------------------------
   libuais vdm/vdo sentence parsing Test functions
   Copyright 2006-2008 by Brian C. Lane <bcl@brianlane.com>
   All rights Reserved
   ----------------------------------------------------------------------- */

/*! \file
    \brief Header file for seaway.c Test functions

*/
void test_seaway();
void test_seaway_msgs();
