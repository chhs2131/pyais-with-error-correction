/* -----------------------------------------------------------------------
   libuais vdm/vdo sentence parsing Test functions
   Copyright 2006-2008 by Brian C. Lane <bcl@brianlane.com>
   All rights Reserved
   ----------------------------------------------------------------------- */

/*! \file
    \brief Header file for vdm_parse.c Test functions

*/
int test_ais2ascii( void );
int test_pos2ddd( void );
int test_pos2dmm( void );
int test_conv_pos( void );
int test_assemble_vdm( void );
int test_ais_1( void );
int test_ais_2( void );
int test_ais_3( void );
int test_ais_4( void );
int test_ais_5( void );
int test_ais_6( void );
int test_ais_7( void );
int test_ais_8( void );
int test_ais_9( void );
int test_ais_10( void );
int test_ais_11( void );
int test_ais_12( void );
int test_ais_13( void );
int test_ais_14( void );
int test_ais_15( void );
int test_ais_16( void );
int test_ais_17( void );
int test_ais_18( void );
int test_ais_19( void );
int test_ais_20( void );
int test_ais_21( void );
int test_ais_22( void );
int test_ais_23( void );
int test_ais_24A( void );
int test_ais_24B( void );
