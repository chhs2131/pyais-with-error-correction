package com.aisparser;

import junit.framework.TestCase;

public class SotdmaTest extends TestCase {
	public void testParse() {
		fail("Not yet implemented");
	}
}
