package com.aisparser;

import junit.framework.TestCase;

public class MessagesTest extends TestCase {
	public void testParse() {
		fail("Not yet implemented");
	}

}
