package com.aisparser;

import junit.framework.TestCase;

public class ItdmaTest extends TestCase {

	public void testParse() {
		fail("Not yet implemented");
	}
}
